<?php
	class connect
	{
		private $con;
		private $host='localhost';
		private $user='root';
		private $pwd='';
		private $db='data1';
		
		function __construct()
		{
			$this->con=mysql_connect($this->host,$this->user,$this->pwd) or die("Unable To Connect To Local Host");
			mysql_select_db($this->db,$this->con) or die("Unable To Connect To Database");
		}
		
		function save_records($name,$password)
		{
			$sql="INSERT INTO password(name,password) VALUES('$name','$password')";
			$n=mysql_query($sql,$this->con);
		}
	}
?>

<?php
	$ob=new connect();
?>
<?php
	if(isset($_POST['submit']))
	{
		$name=$_POST['name'];
		$pass=md5($_POST['password']);
		$ob->save_records($name,$password);
	}
?>



<form name="form1" method="post" action="">
  <table width="90%" border="3" cellspacing="2" cellpadding="13">
    <tr>
      <td width="51%">User Name : </td>
      <td width="51%"><label>
        <input name="name" type="text" id="name">
      </label></td>
    </tr>
    <tr>
      <td>Password : s</td>
      <td><input name="password" type="password" id="password"></td>
    </tr>
    <tr>
      <td colspan="2"><label>
        <input type="submit" name="submit" value="submit">
      </label></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
  </table>
</form>


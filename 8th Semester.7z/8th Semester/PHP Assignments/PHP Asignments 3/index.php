<?php
	$fname='';
	$size='';
	$b=false;
	if(isset($_POST['Submit']))
	{
		$fname=$_FILES['file']['name'];
		$size=$_FILES['file']['size'];
		$source=$_FILES['file']['tmp_name'];
		$target="upload//$fname";
		$b=move_uploaded_file($source,$target);
	}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>File Uploader</title>
</head>

<body>
	<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
		  <table width="90%" border="1" align="center" cellpadding="10" cellspacing="0">
				<tr>
				  <td>UploadFile</td>
				  <td><label>
					<input type="file" name="file" />
					<input type="submit" name="Submit" value="Upload File" />
				  </label></td>
				</tr>
				<tr>
				  <td>File Name </td>
				  <td><?php echo $fname;?></td>
				</tr>
				<tr>
				  <td>File Size </td>
				  <td><?php echo $size;?></td>
				</tr>
				<?php
					if($b)
					{
				?>
				<tr>
				  <td colspan="2">File Uploaded Successfully !!!</td>
				</tr>
				<?php
				}
				?>
		  </table>

	</form>
</body>
</html>

<?php
	class connect
	{
		private $con;
		private $host='localhost';
		private $user='root';
		private $pwd='';
		private $db='result';
		
		function __construct()
		{
			$this->con=mysql_connect($this->host,$this->user,$this->pwd) or die("Unable To Connect To Local Host!");
			mysql_select_db($this->db,$this->con) or die("Unable To Connect To Database!");
		}
		
		function save_records($name,$sub1,$sub2,$sub3,$sub4,$sub5,$marks,$total,$percentage)
		{
			$sql="INSERT INTO class1(name,subject1,subject2,subject3,subject4,subject5,marks,total,percentage) VALUES('$name','$subject1','$subject2','$subject3','$subject4','$subject5','$marks','$total','$percentage')";
			$n=mysql_query($sql,$this->con);
		}
		
		function update()
		{
			$sql="UPDATE class1 SET subject5='99', WHERE name='Rohan'";
			$res=mysql_query($sql,$this->con);
		}
	}
?>
<?php
	$ob=new connect();
?>
<?php
	if(isset($_POST['Submit']))
	{
		$name=$_POST['name'];
		$sub1=$_POST['subject1'];
		$sub2=$_POST['subject2'];
		$sub3=$_POST['subject3'];
		$sub4=$_POST['subject4'];
		$sub5=$_POST['subject5'];
		$marks=$subject1+$subject2+$subject3+$subject4+$subject5;
		$total=500;
		$percentage=($marks/$total)*100;
		$ob->save_records($name,$subject1,$subject2,$subject3,$subject4,$subject5,$marks,$total,$percentage);
		$ob->update();
	}
?>








<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="80%" border="1" cellspacing="0" cellpadding="10">
    <tr>
      <td colspan="2">STUDENT MARKSHEET </td>
    </tr>
    <tr>
      <td width="44%">Name of the Student </td>
      <td width="56%"><label>
        <input name="name" type="text" id="name" />
      </label></td>
    </tr>
    <tr>
      <td colspan="2">Marks in each subject </td>
    </tr>
    <tr>
      <td>Subject 1</td>
      <td><input name="subject1" type="text" id="subject1" /></td>
    </tr>
    <tr>
      <td>Subject 2</td>
      <td><input name="subject2" type="text" id="subject2" /></td>
    </tr>
    <tr>
      <td>Subject 3</td>
      <td><input name="subject3" type="text" id="subject3" /></td>
    </tr>
    <tr>
      <td>Subject 4</td>
      <td><input name="subject4" type="text" id="subject4" /></td>
    </tr>
    <tr>
      <td>Subject 5</td>
      <td><input name="subject5" type="text" id="subject5" /></td>
    </tr>
    <tr>
      <td>Total Marks Obtained </td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Total Marks </td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Percentage</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2"><label>
        <input type="submit" name="Submit" value="Submit" />
      </label></td>
    </tr>
  </table>
</form>
</body>
</html>

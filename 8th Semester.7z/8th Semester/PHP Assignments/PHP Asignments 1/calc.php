<?php
	$a=$_POST['t1'];
	$b=$_POST['t2'];
	$n=0;
	$n=$_POST['select'];
?>
<?php
	$r=0;
	if($n=='+')
		$r=$a+$b;
	else if($n=='-')
		$r=$a-$b;
	else if($n=='*')
		$r=$a*$b;
	else if($n=='/')
		$r=$a/$b;
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Calculator</title>
<style>

</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="50%" border="1" cellspacing="1" cellpadding="13">
    <tr bgcolor="#6a1fba">
      <td colspan="5"><div align="center" class="style1">RESULT : </div></td>
    </tr>
    <tr bgcolor="#1ac951">
      <td><span class="style2"></span><?php echo $a; ?></td>
      <td><span class="style2"></span><?php echo $n; ?></td>
      <td><span class="style2"></span><?php echo $b; ?></td>
      <td><span class="style2"></span>=</td>
      <td><span class="style2"></span><?php echo $r; ?></td>
    </tr>
  </table>
</form>
</body>
</html>

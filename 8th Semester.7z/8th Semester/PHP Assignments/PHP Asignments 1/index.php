


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Index Operator</title>

<style>

</style>

</head>

<body>
<form id="form1" name="form1" method="post" action="calc.php">
  <table width="50%" border="1" cellspacing="0" cellpadding="10">
    <tr bgcolor="#009999">
      <td colspan="3" bordercolor="#d80a06" bgcolor="#35e81e"><div align="center" class="style1">CALCULATOR</div></td>
    </tr>
    <tr>
      <td width="25%" bgcolor="#1f0adb"><span class="style4">First No. : </span></td>
      <td width="5%" bgcolor="#1f0adb"><span class="style4">:</span></td>
      <td width="70%" bgcolor="#1f0adb"><strong>
        <label>
        <input name="t1" type="text" id="t1" />
          </label>
      </strong></td>
    </tr>
    <tr>
      <td bgcolor="#1f0adb"><span class="style4">Second No. : </span></td>
      <td bgcolor="#1f0adb"><span class="style4">:</span></td>
      <td bgcolor="#1f0adb"><strong>
        <label>
        <input name="t2" type="text" id="t2" />
          </label>
      </strong></td>
    </tr>
    <tr>
      <td bgcolor="#1f0adb"><span class="style4">Operator : </span></td>
      <td bgcolor="#1f0adb"><span class="style4">:</span></td>
      <td bgcolor="#1f0adb"><strong>
        <label>
        <select name="select">
		<option value="+">+</option>
		<option value="-">-</option>
		<option value="*">*</option>
		<option value="/">/</option>
        </select>
          </label>
      </strong></td>
    </tr>
    <tr bgcolor="#1f0adb">
      <td colspan="3"><label>
        <div align="center">
          <input type="submit" name="Submit" value="submit" />
          </div>
      </label></td>
    </tr>
  </table>
</form>
</body>
</html>

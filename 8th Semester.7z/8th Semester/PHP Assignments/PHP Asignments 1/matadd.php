<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Matrix Addition</title>
</head>



<?php
	$a=array(2,3);
	$b=array(5,6);
	$c=array($a,$b);
	echo "First matrix : ";
	echo "<br>";
	for($i=0;$i<2;$i++)
	{
		for($j=0;$j<2;$j++)
		echo($c[$i][$j]." ");
		echo "<br>";
	}
	echo "<br>";echo "<br>";
	echo "Second matrix : ";
	echo "<br>";
	$d=array(7,8);
	$e=array(9,10);
	$f=array($d,$e);
	for($i=0;$i<2;$i++)
	{
		for($j=0;$j<2;$j++)
		echo($f[$i][$j]." ");
		echo "<br>";
	}
	for($i=0;$i<2;$i++)
	{
		for($j=0;$j<2;$j++)
		{
			$sum[$i][$j]=$c[$i][$j]+$f[$i][$j];
		}
	}
	echo "The Resultant Matrix is ";
	echo "<br>";
	for($i=0;$i<2;$i++)
	{
		for($j=0;$j<2;$j++)
		echo($sum[$i][$j]." ");
		echo "<br>";
	}34 	
?>
<body>
</body>
</html>

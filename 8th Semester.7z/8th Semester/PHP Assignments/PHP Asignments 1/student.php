<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Student Percentage</title>
</head>

<body>

<form method="post">
 
Enter Name of Student<input type="text" name="name"/>
 
Enter marks in Subject 1 : <input type="text" name="marks1"/>
 

Enter marks in Subject 2 : <input type="text" name="marks2"/>
 

Enter marks in Subject 3 : <input type="text" name="marks3"/>
 

Enter marks in Subject 4 : <input type="text" name="marks4"/>
 

Enter marks in Subject 5 : <input type="text" name="marks5"/>
 
<input type="submit"/>
 
</form>



<?php
	$m1=$_POST['marks1'];
	$m2=$_POST['marks2'];
	$m3=$_POST['marks3'];
	$m4=$_POST['marks4'];
	$m5=$_POST['marks5'];
	echo "Total marks obtained = ";
	$total=$m1+$m2+$m3+$m4+$m5;
	echo $total;
	echo "<br>";
	echo "Total marks = 500";
	echo "<br>";
	echo "Percentage of Student = ";
	$percent=($total/500)*100;
	echo $percent;
?>

</body>

</html>

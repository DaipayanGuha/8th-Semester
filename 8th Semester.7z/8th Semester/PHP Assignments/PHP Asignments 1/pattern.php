<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Pattern1</title>
</head>

<body>
<form method="post">
 
Enter the number of rows<input type="text" name="no"/>
 
<input type="submit"/>
 
</form>
</body>



<?php
	$n=$_POST['no'];
	$r=0;
	for($r=$n;$r>=1;$r--)
	{
		for($sp=1;$sp<=$r;$sp++)
		{
			echo "*";
		}
		echo "<br>";
	}
?>

</html>

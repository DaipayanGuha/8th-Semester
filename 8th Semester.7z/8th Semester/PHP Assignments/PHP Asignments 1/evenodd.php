<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Even or Odd Checker</title>
</head>

<body>
<form method="post">
 
Enter an Integer : <input type="text" name="no"/>
 
<input type="submit"/>
 
</form>
</body>



<?php
	$n=$_POST['no'];
	
	if($n%2==0)
	{
		echo "It is an Even Number.";
	}
	else
	{
		echo "It is an Odd Number.";
	}
	
?>

</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Triangle Type</title>
</head>

<body>

<form method="post">
 
Enter length of First Side : <input type="text" name="side1"/>
Enter length of Second Side : <input type="text" name="side2"/>
Enter length of Third Side : <input type="text" name="side3"/>

 
<input type="submit"/>
 
</form>



<?php
	$s1=$_POST['side1'];
	$s2=$_POST['side2'];
	$s3=$_POST['side3'];
	$a=$s1*$s1;
	$b=$s2*$s2;
	$c=$s3*$s3;
	
	 if($s1==$s2 && $s2==$s3 && $s1==$s3)
		echo "Equilateral Triangle";
	else if($s1==$s2 || $s1==$s3 || $s2==$s3)
		echo "Isosceles Triangle";
	else if((($a+$b)==$c) || (($b+$c)==$a) || (($a+$c)==$b))
		echo "Right Angled Triangle";
	else if($s1!=$s2 && $s1!=$s3 && $s2!=$s3)
		echo "Scalene Triangle";
	
?>

</body>

</html>
